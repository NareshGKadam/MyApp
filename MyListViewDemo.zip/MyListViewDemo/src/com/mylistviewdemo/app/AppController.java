package com.mylistviewdemo.app;

import java.util.HashMap;
import java.util.Map;

import android.app.Application;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;
import com.mylistviewdemo.app.util.HttpsTrustManager;
import com.mylistviewdemo.app.util.LruBitmapCache;

public class AppController extends Application {
	
	public static final String TAG = AppController.class.getSimpleName();
	
	
	private RequestQueue mRequestQueue;
	private ImageLoader mImageLoader;
	private static AppController mInstance;
	
	private static final String FACEBOOK_APP_ID = "1583184861976215";     //facebook Id  
	
	private static final String APP_NAMESPACE = "xporienceclient";
	private Map<String, Fragment.SavedState> savedStateMap;
	
	//  "com.xporience.client_sha
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		mInstance = this;
		savedStateMap = new HashMap<String, Fragment.SavedState>();
		
//		FileUtils.initDirs();
		
		HttpsTrustManager.allowAllSSL();// SSL verification
		
		   
     
	}

	public static synchronized AppController getInstance() {
		return mInstance;
	}

	public RequestQueue getRequestQueue() {
		if (mRequestQueue == null) {
			mRequestQueue = Volley.newRequestQueue(getApplicationContext());
		}

		return mRequestQueue;
	}

	public ImageLoader getImageLoader() {
		getRequestQueue();
		if (mImageLoader == null) {
			mImageLoader = new ImageLoader(this.mRequestQueue,
					new LruBitmapCache());
		}
		return this.mImageLoader;
	}

	public <T> void addToRequestQueue(Request<T> req, String tag) {
		// set the default tag if tag is empty
		req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
		
		getRequestQueue().add(req);
	}

	public <T> void addToRequestQueue(Request<T> req) {
		req.setTag(TAG);
		getRequestQueue().add(req);
	}

	public void cancelPendingRequests(Object tag) {
		if (mRequestQueue != null) {
			mRequestQueue.cancelAll(tag);
		}
	}

	
	public void setFragmentSavedState(String key, Fragment.SavedState state){
        savedStateMap.put(key, state);
    }

    public Fragment.SavedState getFragmentSavedState(String key){
        return savedStateMap.get(key);
    }
    
    
    
    
    /**
	 * add request to queue
	 * 
	 * @param request
	 * @param tag
	 */
	public <T> void addTorequestQueue(Request<T> request, String tag) {
		request.setTag(tag);
		getRequestQueue().add(request);
	}

	/**
	 * cancels the request
	 * 
	 * @param tag
	 */
	public void cancelPendingRequest(Object tag) {
		getRequestQueue().cancelAll(tag);
	}


	
}
