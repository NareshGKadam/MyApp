package com.mylistviewdemo.app.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.Spannable;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SectionIndexer;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.Request.Method;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.mylistviewdemo.app.R;
import com.mylistviewdemo.app.util.ImageLoader;
import com.mylistviewdemo.app.util.Utils;

@SuppressLint("ValidFragment")
public class MainActivity extends Activity implements SwipeRefreshLayout.OnRefreshListener{

	private SwipeRefreshLayout swipeLayout;
	View empty;
	View emptyFav;
	View emptyFavFound;
	ArrayList<Map<String, String>> mListMainList = new ArrayList<Map<String, String>>();
	MyAdapter1 adapter;
	Context mContext;
	String searchedText="";
	ListView mListView;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.fragment_products);

		initUI();

		listCall();


	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}




	private void initUI() {
		mContext = MainActivity.this;

		empty = findViewById(R.id.txtNoExpoFound);
		emptyFav = findViewById(R.id.txtNoFavExpo);
		emptyFavFound = findViewById(R.id.txtNoExpo);


		swipeLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
		swipeLayout.setOnRefreshListener(this);
		swipeLayout.setColorScheme(android.R.color.holo_blue_bright, 
				android.R.color.holo_green_light, 
				android.R.color.holo_orange_light, 
				android.R.color.holo_red_light);

		mListView = (ListView) findViewById(R.id.listview);

		try {
			mListMainList.clear();

			adapter = new MyAdapter1(mContext, mListMainList);
			adapter.notifyDataSetChanged(); // newly added 3-3-15
			mListView.setAdapter(adapter);
			mListView.setFastScrollEnabled(true);



			if (adapter.isEmpty()) {
				emptyFav.setVisibility(View.GONE);
				emptyFavFound.setVisibility(View.GONE);
				mListView.setEmptyView(empty);
			}


		} catch (Exception e) {
			emptyFav.setVisibility(View.GONE);
			emptyFavFound.setVisibility(View.GONE);
			mListView.setEmptyView(empty);
		}



	}


	@Override
	public void onPause() {
		super.onPause();
		Log.i("------>>","speaker onpause()");
	}

	@Override
	public void onResume() {
		super.onResume();


	}



	public void listCall() {

		if (Utils.checkeInternetConnection(mContext)) {

			final Dialog d=new Dialog(mContext);
			d.setContentView(R.layout.progress);
			d.setCancelable(false);
			d.show();

			String url="https://dl.dropboxusercontent.com/u/746330/facts.json";

			RequestQueue mRequestQueue = Volley.newRequestQueue(this);
			//			JsonObjectRequest request = new JsonObjectRequest(Method.GET, cityListUrl, null, new

			JsonObjectRequest jsonObjReq = new JsonObjectRequest(Method.GET,
					url, null, new Response.Listener<JSONObject>() {
				@Override
				public void onResponse(JSONObject response) {
					Log.i("resp--i am attending>  ", "load-->"	+ response);
					try {
						d.dismiss();

						String ss=response.getString("title");
						getActionBar().setTitle(""+ss);
						JSONArray jArr=response.getJSONArray("rows");

						mListMainList.clear();

						for (int i = 0; i < jArr.length(); i++) {
							JSONObject j=jArr.getJSONObject(i);
							Map<String,String> item=new HashMap<String, String>();


							if (j.isNull("title")) {
								item.put("title","");
							}else{
								item.put("title",""+j.getString("title"));
							}

							if (j.isNull("description")) {
								item.put("desc","");
							}else{
								item.put("desc",""+j.getString("description"));
							}

							if (j.isNull("imageHref")) {
								item.put("pic","");
							}else{
								item.put("pic",""+j.getString("imageHref"));
							}


							mListMainList.add(item);


						}

						adapter = new MyAdapter1(mContext, mListMainList);
						adapter.notifyDataSetChanged(); // newly added 3-3-15
						mListView.setAdapter(adapter);
						mListView.setFastScrollEnabled(true);


						if (adapter.isEmpty()) {
							emptyFav.setVisibility(View.GONE);
							emptyFavFound.setVisibility(View.GONE);
							mListView.setEmptyView(empty);
						}

					} catch (Exception e) {

					}
				}
			}, new Response.ErrorListener() {
				@Override
				public void onErrorResponse(VolleyError error) {
					d.dismiss();
					Log.d("onErrorResponse  get tips ", "load-->" + error);
				}
			});
			/*jsonObjReq.setRetryPolicy(new DefaultRetryPolicy(Globals.timeOutLimit,2,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
			jsonObjReq.setShouldCache(false);
			AppController.getInstance().addTorequestQueue(jsonObjReq, "Expo");*/

			int socketTimeout = 15000;//30 seconds - change to what you want
			RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
			jsonObjReq.setRetryPolicy(policy);
			mRequestQueue.add(jsonObjReq);//,"call1");

		}else{
			Toast.makeText(mContext, "No Internet Connection ", Toast.LENGTH_LONG).show();
		}
	}







	public class MyAdapter1 extends BaseAdapter{  
		private ArrayList<Map<String, String>> stringArray;  
		private Context context;  
		ArrayList<Map<String, String>> mListItemsDummy;
		private LayoutInflater mInflator;		
		ImageLoader imloader;
		public MyAdapter1(Context _context, ArrayList<Map<String, String>> arr) {  
			stringArray = arr;  
			context = _context; 

			this.mInflator = (LayoutInflater) _context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			mListItemsDummy = new ArrayList<Map<String, String>>();
			mListItemsDummy.addAll(stringArray);

			imloader=new ImageLoader(context);

		} 


		public int getCount() {  
			return mListItemsDummy.size();  
		}  
		public Object getItem(int arg0) {  
			return mListItemsDummy.get(arg0);  
		}  
		public long getItemId(int arg0) {  
			return 0;  
		}  
		public View getView(final int position, View view, ViewGroup parent) {  

			try {

				ViewHolder holder;


				if (view == null) {
					LayoutInflater inflate = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					view = (View) inflate.inflate(R.layout.list_item_products, null);  

					holder = new ViewHolder();
					holder.mTitle = (TextView) view.findViewById(R.id.tvTitle);
					holder.mDesc = (TextView) view.findViewById(R.id.tvDesc);
					holder.mPic = (ImageView) view.findViewById(R.id.imgPic);
					view.setTag(holder);
				}
				else {
					holder = (ViewHolder)  view.getTag();
				}

				holder.mTitle.setText(""+mListItemsDummy.get(position).get("title"));
				holder.mDesc.setText(""+mListItemsDummy.get(position).get("desc"));
				imloader.DisplayImage(""+mListItemsDummy.get(position).get("pic"), holder.mPic,R.drawable.thumbnail_rect);

				return view;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return view;
		}  





	}

	static class ViewHolder {
		private TextView mTitle;
		private TextView mDesc;
		private ImageView mPic;
	}






	@Override
	public void onRefresh() {

		listCall();


		new Handler().postDelayed(new Runnable() {
			@Override public void run() {
				swipeLayout.setRefreshing(false);
			}
		}, 5000);

	}





}
