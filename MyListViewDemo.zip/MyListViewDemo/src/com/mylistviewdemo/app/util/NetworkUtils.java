package com.mylistviewdemo.app.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.telephony.TelephonyManager;
import android.util.Log;

public class NetworkUtils {
	
//	public static boolean isConnectingToInternet(Context con) {
//		ConnectivityManager connectivity = (ConnectivityManager) con
//				.getSystemService(Context.CONNECTIVITY_SERVICE);
//		if (connectivity != null) {
//			NetworkInfo[] info = connectivity.getAllNetworkInfo();
//			if (info != null)
//				for (int i = 0; i < info.length; i++)
//						if (info[i].getState() == NetworkInfo.State.CONNECTED) {
//							return true;
//						}
//
//		}
//		return false;
//	}
	
	
//	public static boolean isConnectingToInternet(Context con) {
//		ConnectivityManager connectivity = (ConnectivityManager) con
//				.getSystemService(Context.CONNECTIVITY_SERVICE);
//		if (connectivity != null) {
//			NetworkInfo info = connectivity.getActiveNetworkInfo();
//				if ((info != null) && info.isConnected() && NetworkUtils.isConnectionFast(con,info.getType(), info.getSubtype())) {
//					return true;
//				}
//
//		}
//		return false;
//	}
	
	public static boolean isConnectingToInternet(Context con) {   //isInternetFast
		ConnectivityManager connectivity = (ConnectivityManager) con.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivity != null) {
			NetworkInfo info = connectivity.getActiveNetworkInfo();
				if ((info != null)) {
					if(info.isConnected())
					{
						try {
							if(NetworkUtils.isConnectionFast(con,info.getType(), info.getSubtype()))
							{
								return true;
							}else
							{
								return false;
							}
						} catch (Exception e) {
							e.printStackTrace();
							return true;
						}
					}else
					{
						return false;
					}
				}else
				{
					return false;
				}
		}
		return false;
	}
	
	
	public static String getHost(String url){
	    if(url == null || url.length() == 0)
	        return "";

	    int doubleslash = url.indexOf("//");
	    if(doubleslash == -1)
	        doubleslash = 0;
	    else
	        doubleslash += 2;

	    int end = url.indexOf('/', doubleslash);
	    end = end >= 0 ? end : url.length();

	    int port = url.indexOf(':', doubleslash);
	    end = (port > 0 && port < end) ? port : end;

	    return url.substring(doubleslash, end);
	}
	
/*	public static boolean isConnectionFast(Context con, final int type, final int subType) {
		if (type == ConnectivityManager.TYPE_WIFI) {
//			WifiManager wifiManager = (WifiManager) con.getSystemService(Context.WIFI_SERVICE);
//			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
//			if (wifiInfo != null) {
//			    Integer linkSpeed = wifiInfo.getLinkSpeed(); //measured using WifiInfo.LINK_SPEED_UNITS
//			    Log.i("network utils xporience client ","wifi speed====>"+linkSpeed);
//			}
			return true;
		} else if (type == ConnectivityManager.TYPE_MOBILE) {
//			TelephonyManager telephonyManager = (TelephonyManager)con.getSystemService(Context.TELEPHONY_SERVICE);
//			CellInfoGsm cellinfogsm = (CellInfoGsm)telephonyManager.getAllCellInfo().get(0);
//			CellSignalStrengthGsm cellSignalStrengthGsm = cellinfogsm.getCellSignalStrength();
//			Integer mobSpeed = cellSignalStrengthGsm.getDbm();
//			Log.i("network utils xporience client ","mob speed====>"+mobSpeed);
			Log.i("network utils xporience client ","mob subType====>"+subType);
			switch (subType) {
				case TelephonyManager.NETWORK_TYPE_1xRTT:
					return true; // ~ 50-100 kbps
				case TelephonyManager.NETWORK_TYPE_CDMA:
					return false; // ~ 14-64 kbps
				case TelephonyManager.NETWORK_TYPE_EDGE:
					return true; // ~ 50-100 kbps
				case TelephonyManager.NETWORK_TYPE_EVDO_0:
					return true; // ~ 400-1000 kbps
				case TelephonyManager.NETWORK_TYPE_EVDO_A:
					return true; // ~ 600-1400 kbps
				case TelephonyManager.NETWORK_TYPE_GPRS:
					return true; // ~ 100 kbps
				case TelephonyManager.NETWORK_TYPE_HSDPA:
					return true; // ~ 2-14 Mbps
				case TelephonyManager.NETWORK_TYPE_HSPA:
					return true; // ~ 700-1700 kbps
				case TelephonyManager.NETWORK_TYPE_HSUPA:
					return true; // ~ 1-23 Mbps
				case TelephonyManager.NETWORK_TYPE_UMTS:
					return true; // ~ 400-7000 kbps
					
					 * Above API level 7, make sure to set
					 * android:targetSdkVersion
					 * to appropriate level to use these
					 
				case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
					return true; // ~ 1-2 Mbps
				case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
					return true; // ~ 5 Mbps
				case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
					return true; // ~ 10-20 Mbps
				case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
					return false; // ~25 kbps
				case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
					return true; // ~ 10+ Mbps
					// Unknown
				case TelephonyManager.NETWORK_TYPE_UNKNOWN:
				default:
					return false;
			}
		} else {
			return false;
		}
	}*/
	
	// new 3 Feb 2016
	public static boolean isConnectionFast(Context con, final int type, final int subType) {
		if (type == ConnectivityManager.TYPE_WIFI) {
//			WifiManager wifiManager = (WifiManager) con.getSystemService(Context.WIFI_SERVICE);
//			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
//			if (wifiInfo != null) {
//			    Integer linkSpeed = wifiInfo.getLinkSpeed(); //measured using WifiInfo.LINK_SPEED_UNITS
//			    Log.i("network utils xporience client ","wifi speed====>"+linkSpeed);
//			}
			return true;
		} else if (type == ConnectivityManager.TYPE_MOBILE) {
			Log.i("network utils xporience client ","mob subType====>"+subType);
			switch (subType) {
				/*case TelephonyManager.NETWORK_TYPE_1xRTT:
					return true; // ~ 50-100 kbps
				case TelephonyManager.NETWORK_TYPE_CDMA:
					return false; // ~ 14-64 kbps
				case TelephonyManager.NETWORK_TYPE_EDGE:
					return true; // ~ 50-100 kbps
				case TelephonyManager.NETWORK_TYPE_EVDO_0:
					return true; // ~ 400-1000 kbps
				case TelephonyManager.NETWORK_TYPE_EVDO_A:
					return true; // ~ 600-1400 kbps
				case TelephonyManager.NETWORK_TYPE_GPRS:
					return true; // ~ 100 kbps
				case TelephonyManager.NETWORK_TYPE_HSDPA:
					return true; // ~ 2-14 Mbps
				case TelephonyManager.NETWORK_TYPE_HSPA:
					return true; // ~ 700-1700 kbps
				case TelephonyManager.NETWORK_TYPE_HSUPA:
					return true; // ~ 1-23 Mbps
				case TelephonyManager.NETWORK_TYPE_UMTS:
					return true; // ~ 400-7000 kbps
					
					 * Above API level 7, make sure to set
					 * android:targetSdkVersion
					 * to appropriate level to use these
					 
				case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
					return true; // ~ 1-2 Mbps
				case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
					return true; // ~ 5 Mbps
				case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
					return true; // ~ 10-20 Mbps
				case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
					return false; // ~25 kbps
				case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
					return true; // ~ 10+ Mbps
					// Unknown
*/					
					
				case TelephonyManager.NETWORK_TYPE_GPRS:   // ~ 100 kbps   subType=1 Download speed 53.6 kb/s and Upload speed 26.8 kb/s
		        case TelephonyManager.NETWORK_TYPE_CDMA:   // ~ 14-64 kbps subType=4
		        case TelephonyManager.NETWORK_TYPE_1xRTT:  // ~ 50-100 kbps subType=7
		        case TelephonyManager.NETWORK_TYPE_IDEN:   // ~25 kbps subType=11
		        	return false;
		        	
		        case TelephonyManager.NETWORK_TYPE_EDGE:   // ~ 50-100 kbps subType=2 Download speed 217.6 kb/s and Upload speed 108.8 kb/s
		        case TelephonyManager.NETWORK_TYPE_UMTS:   // ~ 400-7000 kbps subType=3 Download speed 384 kb/s and Upload speed 128 kb/s
		        case TelephonyManager.NETWORK_TYPE_EVDO_0: // ~ 400-1000 kbps subType=5
		        case TelephonyManager.NETWORK_TYPE_EVDO_A: // ~ 600-1400 kbps subType=6
		        case TelephonyManager.NETWORK_TYPE_HSDPA:  // ~ 2-14 Mbps  subType=8
		        case TelephonyManager.NETWORK_TYPE_HSUPA:  // ~ 1-23 Mbps subType=9
		        case TelephonyManager.NETWORK_TYPE_HSPA:   // ~ 700-1700 kbps  subType=10 Download speed 7.2 Mb/s and Upload speed 3.6 Mb/s
		        case TelephonyManager.NETWORK_TYPE_EVDO_B: // ~ 5 Mbps  subType=12
		        case TelephonyManager.NETWORK_TYPE_EHRPD:  // ~ 1-2 Mbps  subType=14
		        case TelephonyManager.NETWORK_TYPE_HSPAP:  // ~ 10-20 Mbps subType=15
		        	return true;
				
		        case TelephonyManager.NETWORK_TYPE_LTE:    // ~ 10+ Mbps subType=13 Download speed 100 Mb/s and Upload speed 50 Mb/s
		        	return true;
					
				case TelephonyManager.NETWORK_TYPE_UNKNOWN:  //subType=0
				default:
					return false;
			}
		} else {
			return false;
		}
	}
	
}
